"""Scripts individuales de visualización."""
